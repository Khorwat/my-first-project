
export type MarketingMedium = 
  | 'MUG' 
  | 'BILLBOARD' 
  | 'TSHIRT' 
  | 'POSTER' 
  | 'BUS_STOP' 
  | 'TOTE_BAG' 
  | 'SMARTPHONE' 
  | 'PACKAGING'
  | 'MAGAZINE'
  | 'RETAIL_STAND'
  | 'NEON_SIGN'
  | 'TRUCK_WRAP'
  | 'LAPTOP_DECAL'
  | 'MURAL'
  | 'VIDEO_BILLBOARD' 
  | 'DRONE_SHOT' 
  | 'CINEMATIC_AD';

export type AspectRatio = '1:1' | '3:4' | '4:3' | '9:16' | '16:9';
export type AssetType = 'IMAGE' | 'VIDEO';

export interface GeneratedAsset {
  id: string;
  url: string;
  type: AssetType;
  medium: MarketingMedium | 'CUSTOM';
  prompt: string;
  aspectRatio: AspectRatio;
  timestamp: number;
}

export interface TransformationRequest {
  imageB64: string;
  mimeType: string;
  prompt: string;
  aspectRatio?: AspectRatio;
}
