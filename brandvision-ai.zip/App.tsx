
import React, { useState, useEffect, useRef } from 'react';
import { GeminiService } from './services/geminiService';
import { GeneratedAsset, MarketingMedium, AspectRatio } from './types';
import { IMAGE_MEDIUM_CONFIGS, VIDEO_MEDIUM_CONFIGS, LOADING_MESSAGES, VIDEO_LOADING_MESSAGES, ASPECT_RATIOS } from './constants';

declare global {
  // Define AIStudio interface to match the expected global type
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    // Removed 'readonly' modifier to match the environment's pre-existing declaration of 'aistudio'.
    aistudio: AIStudio;
  }
}

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<{ url: string; mimeType: string } | null>(null);
  const [activeAsset, setActiveAsset] = useState<GeneratedAsset | null>(null);
  const [gallery, setGallery] = useState<GeneratedAsset[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessingBG, setIsProcessingBG] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState(LOADING_MESSAGES[0]);
  const [error, setError] = useState<string | null>(null);
  const [selectedRatio, setSelectedRatio] = useState<AspectRatio>('1:1');
  const [hasVideoKey, setHasVideoKey] = useState(false);
  const [customVideoPrompt, setCustomVideoPrompt] = useState('');
  const [showShareToast, setShowShareToast] = useState(false);
  const [currentDescription, setCurrentDescription] = useState<string>('');

  // Image Editor State
  const [isEditing, setIsEditing] = useState(false);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [rotation, setRotation] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Check for video API key on mount
  useEffect(() => {
    const checkKey = async () => {
      // Safety check to ensure aistudio exists before calling
      if (window.aistudio) {
        try {
          const has = await window.aistudio.hasSelectedApiKey();
          setHasVideoKey(has);
        } catch (err) {
          console.error("Failed to check API key status:", err);
        }
      }
    };
    checkKey();
  }, []);

  // Loading message rotation
  useEffect(() => {
    let interval: any;
    if (isLoading || isProcessingBG) {
      // Select appropriate message set based on the type of generation
      const isVideoLoading = activeAsset?.type === 'VIDEO' || (customVideoPrompt && isLoading);
      const messages = isProcessingBG ? ["Removing background...", "Isolating product...", "Cleaning pixels...", "Studio cleanup..."] : (isVideoLoading ? VIDEO_LOADING_MESSAGES : LOADING_MESSAGES);
      
      interval = setInterval(() => {
        setLoadingMsg(prev => {
          const currentIndex = messages.indexOf(prev);
          return messages[(currentIndex + 1) % messages.length];
        });
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isLoading, isProcessingBG, activeAsset, customVideoPrompt]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const b64 = e.target?.result as string;
      setOriginalImage({ url: b64, mimeType: file.type });
      setBrightness(100);
      setContrast(100);
      setRotation(0);
      setIsEditing(false);
      setActiveAsset(null);
      setGallery([]);
      setError(null);
      setCurrentDescription('');
    };
    reader.readAsDataURL(file);
  };

  const applyImageEdits = () => {
    if (!originalImage) return;
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const isVertical = rotation % 180 !== 0;
      canvas.width = isVertical ? img.height : img.width;
      canvas.height = isVertical ? img.width : img.height;
      ctx.filter = `brightness(${brightness}%) contrast(${contrast}%)`;
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.drawImage(img, -img.width / 2, -img.height / 2);
      const processedUrl = canvas.toDataURL(originalImage.mimeType);
      setOriginalImage({ ...originalImage, url: processedUrl });
      setIsEditing(false);
      setBrightness(100);
      setContrast(100);
      setRotation(0);
    };
    img.src = originalImage.url;
  };

  const handleRemoveBackground = async () => {
    if (!originalImage) return;
    setIsProcessingBG(true);
    setLoadingMsg("Removing background...");
    setError(null);
    try {
      const resultUrl = await GeminiService.removeBackground(originalImage.url, originalImage.mimeType);
      setOriginalImage({ ...originalImage, url: resultUrl });
    } catch (err: any) {
      setError(err.message || "Background removal failed.");
    } finally {
      setIsProcessingBG(false);
    }
  };

  const handleVideoActivation = async () => {
    try {
      if (window.aistudio) {
        await window.aistudio.openSelectKey();
        // MUST assume the key selection was successful after triggering openSelectKey() per guidelines
        setHasVideoKey(true);
      } else {
        setError("AI Studio API key selection is not available in this environment.");
      }
    } catch (err) {
      setError("Failed to open key selection dialog.");
    }
  };

  const generateImageMockup = async (medium: (typeof IMAGE_MEDIUM_CONFIGS)[0]) => {
    if (!originalImage) return;
    setIsLoading(true);
    setLoadingMsg(LOADING_MESSAGES[0]);
    setError(null);
    setCurrentDescription('');
    
    try {
      // Run both in parallel for efficiency
      const [resultUrl, description] = await Promise.all([
        GeminiService.transformImage({
          imageB64: originalImage.url,
          mimeType: originalImage.mimeType,
          prompt: medium.prompt,
          aspectRatio: selectedRatio
        }),
        GeminiService.generateProductDescription(originalImage.url, originalImage.mimeType, medium.label)
      ]);

      const newAsset: GeneratedAsset = {
        id: crypto.randomUUID(),
        url: resultUrl,
        type: 'IMAGE',
        medium: medium.type,
        prompt: medium.prompt,
        aspectRatio: selectedRatio,
        timestamp: Date.now()
      };

      setGallery(prev => [newAsset, ...prev]);
      setActiveAsset(newAsset);
      setCurrentDescription(description);
    } catch (err: any) {
      if (err.message?.includes("Requested entity was not found")) {
        setHasVideoKey(false);
        setError("API Key error. Please re-select your key.");
      } else {
        setError(err.message || "Failed to generate image.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const generateVideoMockup = async (prompt: string, mediumType: MarketingMedium | 'CUSTOM') => {
    if (!originalImage) return;
    if (!hasVideoKey) {
      setError("Video generation requires a selected API key. Click 'Activate Video' in the sidebar.");
      return;
    }

    setIsLoading(true);
    setLoadingMsg(VIDEO_LOADING_MESSAGES[0]);
    setError(null);
    setCurrentDescription('');
    
    try {
      const mediumLabel = mediumType === 'CUSTOM' ? 'cinematic video' : 
        VIDEO_MEDIUM_CONFIGS.find(v => v.type === mediumType)?.label || 'video';

      const [videoUrl, description] = await Promise.all([
        GeminiService.generateVideoMockup(
          originalImage.url,
          originalImage.mimeType,
          prompt,
          selectedRatio
        ),
        GeminiService.generateProductDescription(originalImage.url, originalImage.mimeType, mediumLabel)
      ]);

      const newAsset: GeneratedAsset = {
        id: crypto.randomUUID(),
        url: videoUrl,
        type: 'VIDEO',
        medium: mediumType,
        prompt: prompt,
        aspectRatio: (selectedRatio === '16:9' || selectedRatio === '9:16') ? selectedRatio : '16:9',
        timestamp: Date.now()
      };

      setGallery(prev => [newAsset, ...prev]);
      setActiveAsset(newAsset);
      setCurrentDescription(description);
    } catch (err: any) {
      if (err.message?.includes("Requested entity was not found")) {
        setHasVideoKey(false);
        setError("API Key error. Please re-select your key for Video generation.");
      } else {
        setError(err.message || "Video generation failed.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleShare = async () => {
    if (!activeAsset) return;
    try {
      await navigator.clipboard.writeText(activeAsset.url);
      setShowShareToast(true);
      setTimeout(() => setShowShareToast(false), 2000);
    } catch (err) {
      setError("Failed to copy URL to clipboard.");
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 md:py-12">
      {/* Header */}
      <header className="mb-12 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm font-medium mb-4">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
          </span>
          Gemini 2.5 Image & Veo 3.1 Video
        </div>
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent mb-4">
          BrandVision Pro
        </h1>
        <p className="text-slate-400 max-w-2xl mx-auto text-lg italic">
          High-fidelity marketing assets. Instant motion mockups.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Sidebar */}
        <aside className="lg:col-span-4 space-y-6 sticky top-8">
          
          {/* Upload & Edit Asset */}
          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">1. Source Asset</h2>
              {originalImage && !isProcessingBG && (
                <div className="flex gap-2">
                  <button 
                    onClick={handleRemoveBackground}
                    className="text-[10px] font-bold px-2 py-1 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500 hover:text-white transition-all flex items-center gap-1"
                  >
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    Magic BG
                  </button>
                  <button onClick={() => setIsEditing(!isEditing)} className={`text-[10px] font-bold px-2 py-1 rounded ${isEditing ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-400'}`}>
                    {isEditing ? 'Exit Editor' : 'Refine'}
                  </button>
                </div>
              )}
            </div>
            
            <div 
              onClick={() => !isEditing && !isProcessingBG && fileInputRef.current?.click()}
              className={`relative aspect-square border-2 border-dashed rounded-xl overflow-hidden transition-all ${
                originalImage ? 'border-indigo-500/30' : 'border-slate-800 hover:border-slate-700 cursor-pointer'
              } ${isProcessingBG ? 'opacity-50 cursor-wait' : ''}`}
            >
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="image/*" />
              {originalImage ? (
                <div className="relative w-full h-full">
                  <img 
                    src={originalImage.url} 
                    alt="Source" 
                    className={`w-full h-full object-contain ${isProcessingBG ? 'animate-pulse' : ''}`}
                    style={{ filter: isEditing ? `brightness(${brightness}%) contrast(${contrast}%)` : 'none', transform: isEditing ? `rotate(${rotation}deg)` : 'none' }}
                  />
                  {isProcessingBG && (
                    <div className="absolute inset-0 bg-indigo-950/40 flex flex-col items-center justify-center text-center p-4">
                      <div className="w-8 h-8 border-2 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin mb-2" />
                      <span className="text-[10px] font-black text-white uppercase tracking-widest">{loadingMsg}</span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-600 opacity-50">
                  <svg className="w-8 h-8 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 4v16m8-8H4" strokeWidth={2} /></svg>
                  <span className="text-xs font-bold uppercase">Upload Product</span>
                </div>
              )}
            </div>

            {isEditing && (
              <div className="mt-4 space-y-3 p-3 bg-slate-950 rounded-xl border border-slate-800 animate-in fade-in duration-300">
                <input type="range" min="50" max="150" value={brightness} onChange={(e) => setBrightness(parseInt(e.target.value))} className="w-full h-1 accent-indigo-500 bg-slate-800 rounded-lg appearance-none cursor-pointer" />
                <input type="range" min="50" max="150" value={contrast} onChange={(e) => setContrast(parseInt(e.target.value))} className="w-full h-1 accent-indigo-500 bg-slate-800 rounded-lg appearance-none cursor-pointer" />
                <div className="flex gap-2">
                  <button onClick={() => setRotation(r => r + 90)} className="flex-1 py-1.5 bg-slate-800 text-[10px] font-bold rounded">Rotate 90</button>
                  <button onClick={applyImageEdits} className="flex-1 py-1.5 bg-indigo-600 text-[10px] font-bold rounded text-white">Save</button>
                </div>
              </div>
            )}
          </section>

          {/* Aspect Ratios */}
          <section className={`bg-slate-900 border border-slate-800 rounded-2xl p-6 transition-all ${!originalImage || isProcessingBG ? 'opacity-30 pointer-events-none' : ''}`}>
            <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">2. Canvas Ratio</h2>
            <div className="flex flex-wrap gap-2">
              {ASPECT_RATIOS.map(r => (
                <button key={r.value} onClick={() => setSelectedRatio(r.value)} className={`px-2.5 py-1.5 rounded text-[10px] font-bold border transition-all ${selectedRatio === r.value ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400'}`}>
                  {r.label}
                </button>
              ))}
            </div>
          </section>

          {/* Mediums Selection */}
          <section className={`bg-slate-900 border border-slate-800 rounded-2xl p-6 transition-all ${!originalImage || isProcessingBG ? 'opacity-30 pointer-events-none' : ''}`}>
            <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">3. Static Mediums</h2>
            <div className="grid grid-cols-2 gap-2">
              {IMAGE_MEDIUM_CONFIGS.map(m => (
                <button key={m.type} onClick={() => generateImageMockup(m)} disabled={isLoading} className="flex items-center gap-2 p-2 bg-slate-800 border border-slate-700 rounded-lg hover:bg-slate-700 transition-colors">
                  <span className="text-indigo-400 scale-75">{m.icon}</span>
                  <span className="text-[10px] font-bold">{m.label}</span>
                </button>
              ))}
            </div>
          </section>

          {/* Video Mediums */}
          <section className={`bg-slate-900 border border-slate-800 rounded-2xl p-6 transition-all relative overflow-hidden ${!originalImage || isProcessingBG ? 'opacity-30 pointer-events-none' : ''}`}>
             <div className="flex justify-between items-center mb-4">
              <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">4. Cinematic Video</h2>
              {!hasVideoKey && (
                <button onClick={handleVideoActivation} className="text-[9px] font-black px-2 py-0.5 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded animate-pulse">Activate Video</button>
              )}
            </div>
            {!hasVideoKey && (
              <div className="absolute inset-0 z-10 bg-slate-900/60 backdrop-blur-[2px] flex items-center justify-center p-6 text-center">
                <button onClick={handleVideoActivation} className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-[10px] font-black rounded-lg shadow-xl shadow-amber-900/40">
                  Select Paid API Key for Veo
                </button>
              </div>
            )}
            <div className="grid grid-cols-1 gap-2">
              {VIDEO_MEDIUM_CONFIGS.map(m => (
                <button 
                  key={m.type} 
                  onClick={() => generateVideoMockup(m.prompt, m.type)} 
                  disabled={isLoading} 
                  className="flex items-center gap-3 p-2 bg-slate-950 border border-indigo-900/30 rounded-lg hover:border-indigo-500/50 transition-colors text-left"
                >
                  <span className="text-indigo-400">{m.icon}</span>
                  <span className="text-[10px] font-bold uppercase tracking-tighter">{m.label}</span>
                </button>
              ))}
              
              {/* Custom Video Prompt */}
              <div className="mt-4 pt-4 border-t border-slate-800 space-y-2">
                <label className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Custom Motion Prompt</label>
                <textarea
                  value={customVideoPrompt}
                  onChange={(e) => setCustomVideoPrompt(e.target.value)}
                  placeholder="e.g. Floating in a zero-gravity luxury space station, cinematic reflections..."
                  className="w-full h-16 bg-slate-950 border border-slate-800 rounded-lg p-2 text-[10px] text-slate-300 focus:outline-none focus:border-indigo-500/50 resize-none transition-colors"
                />
                <button
                  onClick={() => generateVideoMockup(customVideoPrompt, 'CUSTOM')}
                  disabled={isLoading || !customVideoPrompt.trim()}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 disabled:cursor-not-allowed text-white text-[10px] font-black rounded-lg shadow-lg shadow-indigo-900/40 uppercase tracking-widest transition-all"
                >
                  Generate Custom Video
                </button>
              </div>
            </div>
            <p className="mt-3 text-[9px] text-slate-600 text-center">Video generation takes approx. 45-60s</p>
          </section>
        </aside>

        {/* Main Content */}
        <main className="lg:col-span-8 space-y-6">
          <div className="relative bg-slate-900 border border-slate-800 rounded-3xl min-h-[500px] flex items-center justify-center p-4 overflow-hidden shadow-2xl">
            {isLoading || isProcessingBG ? (
              <div className="text-center space-y-4">
                <div className="w-12 h-12 border-2 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin mx-auto" />
                <div>
                  <p className="text-sm font-bold text-white uppercase tracking-widest animate-pulse">{loadingMsg}</p>
                  <p className="text-[10px] text-slate-500 font-mono mt-1">ESTIMATED COMPLETION: {isProcessingBG ? '0:10' : '0:45'}</p>
                </div>
              </div>
            ) : activeAsset ? (
              <div className="w-full flex flex-col items-center gap-6">
                <div 
                  className="relative group w-full max-w-2xl bg-black rounded-2xl overflow-hidden shadow-2xl border border-white/5"
                  style={{ aspectRatio: activeAsset.aspectRatio.replace(':', '/') }}
                >
                  {activeAsset.type === 'VIDEO' ? (
                    <video key={activeAsset.url} src={activeAsset.url} autoPlay loop playsInline className="w-full h-full object-contain" />
                  ) : (
                    <img src={activeAsset.url} alt="Mockup" className="w-full h-full object-contain" />
                  )}
                  <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/80 to-transparent flex justify-between items-end">
                    <div>
                      <span className="text-[9px] font-black bg-indigo-600 text-white px-2 py-0.5 rounded mr-2 uppercase">{activeAsset.type}</span>
                      <span className="text-[9px] text-slate-400 font-mono italic truncate block max-w-[200px] sm:max-w-md">{activeAsset.prompt}</span>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={handleShare} 
                        className="relative p-2 bg-white/10 hover:bg-indigo-500 rounded-lg text-white transition-all group/share"
                        title="Copy Link"
                      >
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                        </svg>
                        {showShareToast && (
                          <span className="absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 bg-indigo-600 text-[10px] font-bold text-white rounded shadow-lg animate-in fade-in zoom-in duration-200">
                            Copied!
                          </span>
                        )}
                      </button>
                      <a href={activeAsset.url} download={`brandvision-${activeAsset.id}.${activeAsset.type === 'VIDEO' ? 'mp4' : 'png'}`} className="p-2 bg-white/10 hover:bg-indigo-500 rounded-lg text-white transition-all">
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4" strokeWidth={2}/></svg>
                      </a>
                    </div>
                  </div>
                </div>

                {/* AI Product Description */}
                {currentDescription && (
                  <div className="w-full max-w-2xl bg-slate-900/50 backdrop-blur-md border border-slate-800 rounded-2xl p-6 shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="flex items-center gap-2 mb-3">
                      <svg className="w-4 h-4 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">AI Marketing Copy</span>
                    </div>
                    <p className="text-slate-200 text-sm leading-relaxed font-medium">
                      {currentDescription}
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center opacity-20">
                <svg className="w-16 h-16 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" strokeWidth={1}/></svg>
                <p className="text-xs font-black uppercase tracking-[0.3em]">Studio Idle</p>
              </div>
            )}

            {error && (
              <div className="absolute top-4 inset-x-4 p-4 bg-red-950/80 border border-red-500/30 rounded-xl text-red-200 text-xs flex items-center justify-between backdrop-blur-md z-50">
                <p className="font-bold tracking-tight">{error}</p>
                <button onClick={() => setError(null)} className="p-1 hover:bg-white/10 rounded">X</button>
              </div>
            )}
          </div>

          {/* History Gallery */}
          {gallery.length > 0 && (
            <section className="space-y-4">
              <h3 className="text-[10px] font-black text-slate-600 uppercase tracking-widest border-l-2 border-indigo-500 pl-2">Session Assets</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
                {gallery.map(asset => (
                  <button 
                    key={asset.id} 
                    onClick={() => setActiveAsset(asset)}
                    className={`relative aspect-square rounded-xl overflow-hidden border transition-all ${activeAsset?.id === asset.id ? 'ring-2 ring-indigo-500 scale-95' : 'border-slate-800'}`}
                  >
                    {asset.type === 'VIDEO' ? (
                      <video src={asset.url} muted className="w-full h-full object-cover" />
                    ) : (
                      <img src={asset.url} alt="Thumb" className="w-full h-full object-cover" />
                    )}
                    <div className="absolute top-1 right-1 px-1 py-0.5 bg-black/60 rounded text-[7px] font-black text-white uppercase">
                      {asset.type === 'VIDEO' ? 'MP4' : 'IMG'}
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}
        </main>
      </div>

      <footer className="mt-20 py-8 border-t border-slate-900 flex justify-between items-center text-[9px] font-black uppercase text-slate-700 tracking-widest">
        <span>BrandVision AI // Motion & Static Studio</span>
        <div className="flex gap-4">
          <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="hover:text-indigo-400">Billing Docs</a>
          <span className="text-slate-800">|</span>
          <span>Powered by VEO 3.1 Fast</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
