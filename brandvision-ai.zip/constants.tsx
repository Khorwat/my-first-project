
import React from 'react';
import { AspectRatio } from './types';

export const ASPECT_RATIOS: { label: string; value: AspectRatio }[] = [
  { label: '1:1', value: '1:1' },
  { label: '4:3', value: '4:3' },
  { label: '3:4', value: '3:4' },
  { label: '16:9', value: '16:9' },
  { label: '9:16', value: '9:16' },
];

export const IMAGE_MEDIUM_CONFIGS = [
  {
    type: 'MUG' as const,
    label: 'Coffee Mug',
    prompt: 'Naturally wrap this product design or logo onto a clean, glossy white ceramic coffee mug sitting on a minimalist wooden cafe table with soft morning lighting.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v-4l-4 4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
      </svg>
    )
  },
  {
    type: 'BILLBOARD' as const,
    label: 'Urban Billboard',
    prompt: 'Place this product advertisement onto a massive, high-impact outdoor billboard in a bustling metropolitan city center like Times Square. Professional photography, cinematic depth of field, vibrant city lights.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
      </svg>
    )
  },
  {
    type: 'TSHIRT' as const,
    label: 'Apparel Mockup',
    prompt: 'Screen print this product graphic or logo onto the center chest of a high-quality heavyweight black cotton t-shirt worn by a professional model. Studio lighting, realistic fabric folds and texture.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
      </svg>
    )
  },
  {
    type: 'POSTER' as const,
    label: 'Gallery Poster',
    prompt: 'Mount this product artwork as a large framed minimalist poster hanging in a high-end modern art gallery. Soft gallery spot lighting, white walls, sophisticated atmosphere.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
    )
  },
  {
    type: 'BUS_STOP' as const,
    label: 'Bus Shelter',
    prompt: 'Display this brand advertisement inside a backlit glass bus stop shelter at night in a clean European city. Wet pavement reflections, cinematic street atmosphere, soft ambient city glow.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
      </svg>
    )
  },
  {
    type: 'TOTE_BAG' as const,
    label: 'Eco Tote Bag',
    prompt: 'Print this logo or product design onto a premium organic cream-colored canvas tote bag. The bag is hanging from a minimalist wooden hook against a clean white wall. Natural sunlight shadows.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
      </svg>
    )
  },
  {
    type: 'SMARTPHONE' as const,
    label: 'Mobile Screen',
    prompt: 'Display this logo or product perfectly on the screen of a modern bezel-less smartphone held by a professional in a bright, modern minimalist office. Realistic glass reflections and soft focus background.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
      </svg>
    )
  },
  {
    type: 'PACKAGING' as const,
    label: 'Luxury Box',
    prompt: 'Apply this brand artwork onto a premium matte black product packaging box. The box is placed on a clean grey marble surface with high-end studio lighting and elegant soft shadows.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
      </svg>
    )
  },
  {
    type: 'MAGAZINE' as const,
    label: 'Glossy Magazine',
    prompt: 'A double-page glossy magazine spread featuring this product as the primary focus. High-end fashion editorial style, elegant layout, soft professional studio lighting.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
      </svg>
    )
  },
  {
    type: 'RETAIL_STAND' as const,
    label: 'Retail Display',
    prompt: 'A sleek modern retail floor stand in a luxury boutique department store showcasing this product. Professional boutique lighting, clean architectural lines.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    )
  },
  {
    type: 'NEON_SIGN' as const,
    label: 'Neon Brand',
    prompt: 'A vibrant glowing neon light version of this product logo or silhouette, mounted on a dark urban brick wall. Realistic light bloom and reflections in the bar atmosphere.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    )
  },
  {
    type: 'TRUCK_WRAP' as const,
    label: 'Delivery Truck',
    prompt: 'A professional full-vehicle branding wrap of this design on a modern delivery truck driving through a clean urban neighborhood. Realistic metallic surface reflections.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0zM13 13h3a3 3 0 013 3v1M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h11a2 2 0 012 2v11a2 2 0 01-2 2h-2m-3-1v-4a1 1 0 011-1h2a1 1 0 011 1v4h-4z" />
      </svg>
    )
  },
  {
    type: 'LAPTOP_DECAL' as const,
    label: 'Laptop Decal',
    prompt: 'This product design applied as a high-quality vinyl decal on a sleek space-grey laptop lid. Minimalist desktop setup, shallow depth of field.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    )
  },
  {
    type: 'MURAL' as const,
    label: 'Urban Mural',
    prompt: 'A massive spray-painted mural of this branding on a textured concrete wall in an urban arts district. Realistic street art details and outdoor lighting.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
      </svg>
    )
  }
];

export const VIDEO_MEDIUM_CONFIGS = [
  {
    type: 'VIDEO_BILLBOARD' as const,
    label: 'Live Billboard',
    prompt: 'An animated 3D motion graphic advertisement of this product shown on a massive digital billboard in Shinjuku, Tokyo at night. Crowds walking below, rain reflections on pavement, neon lights flickering.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
      </svg>
    )
  },
  {
    type: 'DRONE_SHOT' as const,
    label: 'Drone Cinematics',
    prompt: 'A cinematic drone shot flying over a scenic beach where this product is prominently displayed on a wooden stand. High resolution, 4k, golden hour lighting, gentle ocean waves crashing.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
      </svg>
    )
  },
  {
    type: 'CINEMATIC_AD' as const,
    label: 'Social Media Ad',
    prompt: 'A high-energy, fast-paced cinematic social media advertisement for this product. Dynamic camera movement, shallow depth of field, sleek urban studio environment, modern lighting.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
      </svg>
    )
  }
];

export const LOADING_MESSAGES = [
  "Consulting the creative director...",
  "Applying digital textures...",
  "Rendering marketing excellence...",
  "Adjusting the studio lights...",
  "Polishing pixels for maximum impact...",
  "Calculating the perfect angle...",
  "Thinking about brand synergy..."
];

export const VIDEO_LOADING_MESSAGES = [
  "Firing up the render engines...",
  "Simulating physics and motion...",
  "Animating frames for cinematic flow...",
  "Color grading the motion sequences...",
  "Synchronizing dynamic lighting...",
  "Finalizing high-definition export..."
];
